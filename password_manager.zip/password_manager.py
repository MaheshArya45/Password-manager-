
import tkinter as tk
from tkinter import messagebox
import random
import json

def generate_password():
    letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    numbers = "0123456789"
    symbols = "!#$%&()*+"

    password_letters = [random.choice(letters) for _ in range(random.randint(8, 10))]
    password_symbols = [random.choice(symbols) for _ in range(random.randint(2, 4))]
    password_numbers = [random.choice(numbers) for _ in range(random.randint(2, 4))]

    password_list = password_letters + password_symbols + password_numbers
    random.shuffle(password_list)

    password = "".join(password_list)
    password_entry.delete(0, tk.END)
    password_entry.insert(0, password)

def save_password():
    website = website_entry.get()
    email = email_entry.get()
    password = password_entry.get()
    new_data = {
        website: {
            "email": email,
            "password": password
        }
    }

    if not website or not password:
        messagebox.showwarning(title="Oops", message="Please don't leave any fields empty!")
        return

    try:
        with open("data.json", "r") as data_file:
            data = json.load(data_file)
    except (FileNotFoundError, json.decoder.JSONDecodeError):
        data = {}

    data.update(new_data)

    with open("data.json", "w") as data_file:
        json.dump(data, data_file, indent=4)

    website_entry.delete(0, tk.END)
    password_entry.delete(0, tk.END)
    messagebox.showinfo(title="Success", message="Password saved successfully!")

def find_password():
    website = website_entry.get()
    try:
        with open("data.json", "r") as data_file:
            data = json.load(data_file)
    except (FileNotFoundError, json.decoder.JSONDecodeError):
        messagebox.showerror(title="Error", message="No Data File Found")
        return

    if website in data:
        email = data[website]["email"]
        password = data[website]["password"]
        messagebox.showinfo(title=website, message=f"Email: {email}\nPassword: {password}")
    else:
        messagebox.showinfo(title="Not Found", message="No details for the website exists.")

window = tk.Tk()
window.title("Password Manager")
window.config(padx=50, pady=50)

tk.Label(text="Website:").grid(row=1, column=0)
tk.Label(text="Email/Username:").grid(row=2, column=0)
tk.Label(text="Password:").grid(row=3, column=0)

website_entry = tk.Entry(width=35)
website_entry.grid(row=1, column=1, columnspan=2)
website_entry.focus()

email_entry = tk.Entry(width=35)
email_entry.grid(row=2, column=1, columnspan=2)
email_entry.insert(0, "example@example.com")

password_entry = tk.Entry(width=21)
password_entry.grid(row=3, column=1)

generate_pass_btn = tk.Button(text="Generate Password", command=generate_password)
generate_pass_btn.grid(row=3, column=2)

add_btn = tk.Button(text="Add", width=36, command=save_password)
add_btn.grid(row=4, column=1, columnspan=2)

search_btn = tk.Button(text="Search", width=13, command=find_password)
search_btn.grid(row=1, column=2)

window.mainloop()
